import requests


def convert_currency(from_currency, to_currency, amount):
    url = f"https://api.exchangerate-api.com/v4/latest/{from_currency.upper()}"
    response = requests.get(url)

    if response.status_code != 200:
        print("Failed to retrieve data")
        return

    data = response.json()

    if to_currency.upper() not in data['rates']:
        print("Invalid target currency.")
        return

    rate = data['rates'][to_currency.upper()]
    converted_amount = round(amount * rate, 2)
    print(f"{amount} {from_currency.upper()} = {converted_amount} {to_currency.upper()}")


# Example usage
print("💱 Currency Converter 💱")
from_cur = input("From Currency (e.g., USD): ")
to_cur = input("To Currency (e.g., INR): ")
amt = float(input("Amount to Convert: "))

convert_currency(from_cur, to_cur, amt)