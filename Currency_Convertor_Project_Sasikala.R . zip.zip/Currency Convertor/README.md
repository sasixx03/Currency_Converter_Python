# Currency Converter Project 💱

This is a simple Currency Converter built using Python and the `requests` library.  
It takes input currencies and amount from the user and fetches real-time exchange rates from an online API.

## Technologies Used
- Python
- requests library
- ExchangeRate API

## Example:
   From Currency: USD
   To Currency: INR
    Amount: 10
    Output: 10 USD = 832 INR
   ## Created by:
Sasikala R | BCA Graduate | Shri Shakti Kailash Women’s College (2022–2025)